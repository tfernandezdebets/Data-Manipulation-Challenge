import pandas as pd
pd.set_option('display.max_colwidth', -1)

def question_contains_words(df, lst):
  lst = [' ' + word.lower() + ' ' for word in lst]
  new_df = df[df.Question.apply(lambda x: all(word in x.lower() for word in lst))]
  return new_df

def count_unique_answers(df):
  return df.Answer.nunique()

df = pd.read_csv('jeopardy.csv')
df = df.rename(columns = {'Show Number': 'Show_number', ' Air Date': 'Air_date', ' Round': 'Round', ' Category': 'Category', ' Value': 'Value', ' Question': 'Question', ' Answer': 'Answer'})
list_words = ['King', 'England']

df.Value = df.Value.apply(lambda x: float(x[1:].replace(',', '')) if x != 'None' else 0)

print("The average value of questions that contain the words {} is {:.2f} points. There are {} unique answers to such questions.".format(list_words, question_contains_words(df, list_words).Value.mean(), count_unique_answers(question_contains_words(df, list_words))))
